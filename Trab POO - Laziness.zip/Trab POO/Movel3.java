import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Movel3.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Movel3 extends Parede_Borda
{
    public void act() 
    {
        // Add your action code here.
    }    
}
