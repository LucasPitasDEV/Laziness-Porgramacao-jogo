import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe YouWIn.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class YouWin extends EndGameTexto
{
    public void act() 
    {
        super.act();
    }    
}
