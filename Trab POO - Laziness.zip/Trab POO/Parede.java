import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Parede.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Parede extends Actor
{
    public void act() 
    {
        
    }    
}
