
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Fase1.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Fase1 extends World
{
    public static Counter pontuacao = new Counter();
    public static CountVidas vidas = new CountVidas();
    public static CountVidasBoss bossVidas = new CountVidasBoss();
    
    private static SimpleTimer tempoFase = new SimpleTimer();
    
    public ControlePowerUp ctrlPowerUp = new ControlePowerUp();
    public static Escudo escudo = new Escudo();
    public static Cafe cafe = new Cafe();
    public static Vida vida = new Vida();
    public Pet pet = new Pet();
    public Logo logo = new Logo();
    
    public static GreenfootSound stage1 = new GreenfootSound("stage1.wav");
    public static GreenfootSound stage2 = new GreenfootSound("stage2.wav");
    public static GreenfootSound stage3 = new GreenfootSound("stage3.wav");
    public static GreenfootSound stage4 = new GreenfootSound("stage4.wav");
    public static GreenfootSound stage5 = new GreenfootSound("stage5.wav");
        
    private int tempofase=60000;
    private static int stage;
    private int getX;
    private int getY;
    
    /**
     * Construtor para objetos da classe Fase1.
     * 
     */
    public Fase1()
    {    
        super(600, 400, 1);
        
        pontuacao.setValue(0);
                
        vidas.setValue(3);
        stage1.setVolume(100);
        stage2.setVolume(70);
        stage3.setVolume(70);
        stage4.setVolume(70);
        stage5.setVolume(70);
        
        stage=1;
        tempoFase.mark();
        act();
    }
    
    public void act(){
        if ((tempoFase.millisElapsed()==0)&&(stage==1)){
            prepareQuarto();
            stage++;
            tempoFase.mark();
            if(Greenfoot.getRandomNumber(2)==1){
                addObject(pet, 144,324);
            }
        }
        
        if ((tempoFase.millisElapsed()>tempofase)&&(stage==2)){
            prepareBanheiro();
            stage++;
            tempoFase.mark();
        }
        
        if ((tempoFase.millisElapsed()>tempofase)&&(stage==3)){
            prepareCozinha();
            stage++;
            tempoFase.mark();
        }
        
        if ((tempoFase.millisElapsed()>tempofase)&&(stage==4)){
            prepareSala();
            stage++;
            tempoFase.mark();
        }
        
        if ((tempoFase.millisElapsed()>tempofase)&&(stage==5)){
            prepareBoss();
            stage++;
            if(Greenfoot.getRandomNumber(2)==1){
                addObject(pet, 144,324);
            }
        }
    }

    private void transicao(){
        removeObjects(getObjects(null));
        stage1.stop();
        stage2.stop();
        stage3.stop();
        stage4.stop();
        Greenfoot.playSound("Transicao.wav");
        GreenfootImage transicao = new GreenfootImage("Transicao.png");
        transicao.setColor(Color.WHITE);
        transicao.setFont(new Font(20));
        if(stage!=5){
            transicao.drawString("Carregando Estágio 1-"+stage, 200, 350);
        }
        else{
            transicao.drawString("Carregando BOSS BATTLE", 180, 350);
        }
        setBackground(transicao);
        
        Greenfoot.delay(300);
        
        addObject(pontuacao,504,27);
                        
        addObject(vidas,100,20);
                        
        addObject(ctrlPowerUp,195, 27);
        
        addObject(logo,299,28);
        
        return;
    }
    
    private void prepareQuarto(){        
        transicao();
        
        stage1.playLoop();
        
        ParedeH bordaSuperior = new ParedeH();
        addObject(bordaSuperior,300,27);
        
        ParedeH2 bordaInferior = new ParedeH2();
        addObject(bordaInferior,300,500); 

        ParedeV bordaEsquerda1 = new ParedeV();
        addObject(bordaEsquerda1,20,200);
        
        ParedeV bordaEsquerda2 = new ParedeV();
        addObject(bordaEsquerda2,60,200);

        ParedeV bordaDireita1 = new ParedeV();
        addObject(bordaDireita1,570,200);
        
        ParedeV bordaDireita2 = new ParedeV();
        addObject(bordaDireita2,530,200);

        Movel3 cama = new Movel3();
        addObject(cama,290,331);
        cama.turn(90);

        Movel4 mesaComputador = new Movel4();
        addObject(mesaComputador,300,80);

        Movel camaGato = new Movel();
        addObject(camaGato,140,355);
        
        Movel5 cadeira = new Movel5();
        addObject(cadeira,322,124);         
        
        setBackground("Quarto.png");
        
        Personagem personagem = new Personagem();       

        addObject(personagem,132,95);   

        WhatsApp f1 = new WhatsApp();
        getX = Greenfoot.getRandomNumber(getWidth()-1);
        getY = Greenfoot.getRandomNumber(getHeight()-1);

        addObject(f1,getX, getY);

        for (int i=0; i<5;i++){
            Excel excel = new Excel();
            getX = Greenfoot.getRandomNumber(getWidth()-1);
            getY = Greenfoot.getRandomNumber(getHeight()-1);

            addObject(excel,getX, getY);
        }
    }      
        
    private void prepareBanheiro(){
        transicao();
        
        stage2.playLoop();
        
        ParedeH bordaSuperior = new ParedeH();
        addObject(bordaSuperior,300,27);
        
        ParedeH bordaInferior = new ParedeH();
        addObject(bordaInferior,300,380); 

        ParedeV bordaEsquerda1 = new ParedeV();
        addObject(bordaEsquerda1,20,200);
        
        ParedeV bordaEsquerda2 = new ParedeV();
        addObject(bordaEsquerda2,60,200);

        ParedeV bordaDireita1 = new ParedeV();
        addObject(bordaDireita1,570,200);
        
        ParedeV bordaDireita2 = new ParedeV();
        addObject(bordaDireita2,552,200);

        Movel3 banheira = new Movel3();
        addObject(banheira,164,320);

        Movel4 pias = new Movel4();
        addObject(pias,355,70);
        
        Movel4 maquinas1 = new Movel4();
        addObject(maquinas1,150,110);
        
        Movel4 maquinas2 = new Movel4();
        addObject(maquinas2,150,70);
        
        Movel4 ducha1 = new Movel4();
        addObject(ducha1,503,291);
        
        Movel4 ducha2 = new Movel4();
        addObject(ducha2,503,335);

        Movel cestoRoupas = new Movel();
        addObject(cestoRoupas,296,329);
        
        Movel5 privada = new Movel5();
        addObject(privada,113,172);
        privada.turn(90);
        
        addObject(pontuacao,504,27);
        
        addObject(vidas,100,20);
        
        setBackground("Banheiro.png");
        
        Personagem personagem = new Personagem();       

        addObject(personagem,475,95);
        
        YouTube f2 = new YouTube();
        getX = Greenfoot.getRandomNumber(getWidth()-1);
        getY = Greenfoot.getRandomNumber(getHeight()-1);

        addObject(f2,getX, getY);
        
        for (int i=0; i<5;i++){
            Excel excel = new Excel();
            getX = Greenfoot.getRandomNumber(getWidth()-1);
            getY = Greenfoot.getRandomNumber(getHeight()-1);

            addObject(excel,getX, getY);
        }
    }
    
    private void prepareCozinha(){
        transicao();
        
        stage3.playLoop();
        
        ParedeH bordaSuperior1 = new ParedeH();
        addObject(bordaSuperior1,300,27);
        
        ParedeH bordaSuperior2 = new ParedeH();
        addObject(bordaSuperior2,300,73);
        
        ParedeH2 bordaInferior = new ParedeH2();
        addObject(bordaInferior,300,500); 

        ParedeV bordaEsquerda1 = new ParedeV();
        addObject(bordaEsquerda1,30,200);
        
        ParedeV bordaEsquerda2 = new ParedeV();
        addObject(bordaEsquerda2,50,200);

        ParedeH2 bordaDireita1 = new ParedeH2();
        addObject(bordaDireita1,585,200);
        bordaDireita1.turn(90);

        Movel4 pias = new Movel4();
        addObject(pias,355,70);
        
        Movel4 mesa1 = new Movel4();
        addObject(mesa1,246,241);
        
        Movel4 mesa2 = new Movel4();
        addObject(mesa2,352,241);
        
        Movel4 mesa3 = new Movel4();
        addObject(mesa3,246,278);
        
        Movel4 mesa4 = new Movel4();
        addObject(mesa4,352,278);

        Movel5 cadeira1 = new Movel5();
        addObject(cadeira1,179,246);
        
        Movel5 cadeira2 = new Movel5();
        addObject(cadeira2,238,210);
        
        Movel5 cadeira3 = new Movel5();
        addObject(cadeira3,348,210);
        
        Movel5 cadeira4 = new Movel5();
        addObject(cadeira4,426,246);
        
        setBackground("Cozinha.png");
        
        Personagem personagem = new Personagem();       

        addObject(personagem,294,137);
        
        Facebook f3 = new Facebook();
        getX = Greenfoot.getRandomNumber(getWidth()-1);
        getY = Greenfoot.getRandomNumber(getHeight()-1);

        addObject(f3,getX, getY);

        Instagram f4 = new Instagram();
        getX = Greenfoot.getRandomNumber(getWidth()-1);
        getY = Greenfoot.getRandomNumber(getHeight()-1);

        addObject(f4,getX, getY);
        
        for (int i=0; i<5;i++){
            Excel excel = new Excel();
            getX = Greenfoot.getRandomNumber(getWidth()-1);
            getY = Greenfoot.getRandomNumber(getHeight()-1);

            addObject(excel,getX, getY);
        }
    }
            
    private void prepareSala(){
        /**
        * Prepara o mundo para o início do programa.
        * Ou seja: criar os objetos iniciais e adicioná-los ao mundo.
        */
        transicao();
        
        stage4.playLoop();
        
        ParedeH bordaSuperior = new ParedeH();
        addObject(bordaSuperior,300,10);       

        ParedeV bordaEsquerda = new ParedeV();
        addObject(bordaEsquerda,7,200);

        ParedeV bordaDireita = new ParedeV();
        addObject(bordaDireita,580,200);

        Movel2 mesaTv = new Movel2();
        addObject(mesaTv,311,145);

        Movel3 sofaDireita = new Movel3();
        addObject(sofaDireita,425,280);
        sofaDireita.turn(90);

        Movel3 sofaEsquerda = new Movel3();
        addObject(sofaEsquerda,187,280);
        sofaEsquerda.turn(90);

        Movel4 sofaBaixo = new Movel4();
        addObject(sofaBaixo,308,355);

        Movel mesaCentral = new Movel();
        addObject(mesaCentral,308,265);  
        
        setBackground("Sala.png");
        
        Personagem personagem = new Personagem();       

        addObject(personagem,311,204);

        WhatsApp f5 = new WhatsApp();
        getX = Greenfoot.getRandomNumber(getWidth()-1);
        getY = Greenfoot.getRandomNumber(getHeight()-1);

        addObject(f5,getX, getY);

        YouTube f6 = new YouTube();
        getX = Greenfoot.getRandomNumber(getWidth()-1);
        getY = Greenfoot.getRandomNumber(getHeight()-1);

        addObject(f6,getX, getY);
        
        for (int i=0; i<5;i++){
            Excel excel = new Excel();
            getX = Greenfoot.getRandomNumber(getWidth()-1);
            getY = Greenfoot.getRandomNumber(getHeight()-1);

            addObject(excel,getX, getY);
        }
    }
    
    private void prepareBoss(){
        transicao();
        
        stage5.playLoop();
        
        ParedeH bordaSuperior = new ParedeH();
        addObject(bordaSuperior,300,27);
        
        ParedeH2 bordaInferior = new ParedeH2();
        addObject(bordaInferior,300,500); 

        ParedeV bordaEsquerda1 = new ParedeV();
        addObject(bordaEsquerda1,20,200);
        
        ParedeV bordaEsquerda2 = new ParedeV();
        addObject(bordaEsquerda2,60,200);

        ParedeV bordaDireita1 = new ParedeV();
        addObject(bordaDireita1,570,200);
        
        ParedeV bordaDireita2 = new ParedeV();
        addObject(bordaDireita2,530,200);

        Movel3 cama = new Movel3();
        addObject(cama,290,331);
        cama.turn(90);

        Movel4 mesaComputador = new Movel4();
        addObject(mesaComputador,300,80);

        Movel camaGato = new Movel();
        addObject(camaGato,140,355);
        
        Movel5 cadeira = new Movel5();
        addObject(cadeira,322,124);         
        
        addObject(bossVidas, 160, 209);
        bossVidas.setValue(20);
        bossVidas.teamsTela=0;
        
        ParedeFantasma hp1 = new ParedeFantasma();
        addObject(hp1,37,159);
        hp1.turn(90);
        
        ParedeFantasma hp2 = new ParedeFantasma();
        addObject(hp2,37,311);
        hp2.turn(90);
        
        Laziness l = new Laziness();
        addObject(l, 35, 237);
        
        setBackground("Quarto.png");
        
        Personagem personagem = new Personagem();       

        addObject(personagem,293,207);   

        WhatsApp f1 = new WhatsApp();
        addObject(f1,460, 92);
        
        Facebook f2 = new Facebook();
        addObject(f2,132, 92);
        
        Instagram f3 = new Instagram();
        addObject(f3,132, 342);
        
        YouTube f4 = new YouTube();
        addObject(f4,460, 342);
        

        for (int i=0; i<5;i++){
            Excel excel = new Excel();
            getX = Greenfoot.getRandomNumber(getWidth()-1);
            getY = Greenfoot.getRandomNumber(getHeight()-1);

            addObject(excel,getX, getY);
        }
    } 
}