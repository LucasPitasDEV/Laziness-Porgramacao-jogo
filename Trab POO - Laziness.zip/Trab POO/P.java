import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe P.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class P extends Textos
{
    public void act() 
    {

    }    
}
