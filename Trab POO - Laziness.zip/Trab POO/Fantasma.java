import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Fantasma.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Fantasma extends Actor
{
    protected SimpleTimer timer = new SimpleTimer();
    
    public static GreenfootSound lose = new GreenfootSound("Lose.wav");
    
    protected int rotation;
    
    public void act() 
    {     
        move(2);
        
        if(Greenfoot.getRandomNumber(100)<5)
            turn(Greenfoot.getRandomNumber(90)-45);
            
            
        if (getX()<=5 || getX()>=getWorld().getWidth()-5)
            turn(180);
            
        if (getY()<=5 || getY()>=getWorld().getHeight()-5)
            turn(180);      
        
        checkPersonagem();
        
        if(getOneObjectinFront(ParedeFantasma.class)!=null){
            turn(180);
        }
    }
    
    private Actor getOneObjectinFront(Class c){
        GreenfootImage myImage = getImage();
        int distanceToFront = myImage.getWidth();
        int xOffset = (int) Math.ceil(distanceToFront*Math.cos(Math.toRadians(getRotation())))/2;
        int yOffset = (int) Math.ceil(distanceToFront*Math.sin(Math.toRadians(getRotation())))/2;

        return (getOneObjectAtOffset(xOffset, yOffset, c));
    }
    
    private void checkPersonagem(){
        Actor P;
        P = getOneIntersectingObject(Personagem.class);
        
        if (P !=null){
            if (timer.millisElapsed() > 1000){
                if(Personagem.escudo==true){
                    Greenfoot.playSound("BloqueioEscudo.wav");
                }
                if(Personagem.escudo==false){
                    Fase1.vidas.add(-1);
                    Greenfoot.playSound("Dano.wav");
                }
                
                if(Fase1.vidas.getValue()<1){ 
                    getWorld().removeObject(Fase1.vidas);
                    Fase1.stage1.stop();
                    Fase1.stage2.stop();
                    Fase1.stage3.stop();
                    Fase1.stage4.stop();
                    Fase1.stage5.stop();
                    getWorld().removeObject(P);
                    lose.playLoop();
                    Greenfoot.delay(165);
                    Greenfoot.setWorld(new GameOverScreen());
                }
                timer.mark();
            }
        }
    }
}
