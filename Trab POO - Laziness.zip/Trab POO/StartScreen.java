import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Class StartScreen.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class StartScreen extends World
{
    private GreenfootSound start = new GreenfootSound("Start.wav");
    
    public static boolean startMusic;
    
    /**
     * Construtor para objetos da classe StartScreen.
     * 
     */
    public StartScreen()
    {    
        super(600, 400, 1);

        prepare();
        
        act();     
    }
    
    public void started(){
        startMusic=true;
    }
    
    public void act(){
        musica(startMusic);
        
        if(Greenfoot.isKeyDown("Space")){
            start.stop();
            Greenfoot.playSound("BotoesMenu.wav");
            removeObjects(getObjects(null));
            GreenfootImage transicao = new GreenfootImage("Transicao.png");
            transicao.setColor(Color.WHITE);

            transicao.setFont(new Font(20));
            transicao.drawString("Carregando Estágio 1-1", 200, 350);
            setBackground(transicao);

            Greenfoot.setWorld(new Fase1());
        }

        if(Greenfoot.isKeyDown("l")){
            Greenfoot.playSound("BotoesMenu.wav");
            StartScreen.startMusic=false;
            Greenfoot.setWorld(new ScoreScreen());
        }
        
        if(Greenfoot.isKeyDown("c")){
            Greenfoot.playSound("BotoesMenu.wav");
            StartScreen.startMusic=false;
            Greenfoot.setWorld(new CreditosScreen());
        }
        
        if(Greenfoot.isKeyDown("t")){
            Greenfoot.playSound("BotoesMenu.wav");
            Greenfoot.setWorld(new TutorialScreen());
        }
    }

    /**
     * Prepara o mundo para o início do programa.
     * Ou seja: criar os objetos iniciais e adicioná-los ao mundo.
     */
    private void prepare()
    {
        Facebook facebook = new Facebook();
        addObject(facebook,420,171);
        Instagram instagram = new Instagram();
        addObject(instagram,235,365);
        WhatsApp whatsApp = new WhatsApp();
        addObject(whatsApp,230,233);
        YouTube youTube = new YouTube();
        addObject(youTube,410,308);
        
        ParedeFantasma movel2 = new ParedeFantasma();
        addObject(movel2,318,175);
        ParedeFantasma movel22 = new ParedeFantasma();
        addObject(movel22,318,233);
        ParedeFantasma movel23 = new ParedeFantasma();
        addObject(movel23,318,291);
        ParedeFantasma movel24 = new ParedeFantasma();
        addObject(movel24,318,320);
        ParedeFantasma movel25 = new ParedeFantasma();
        addObject(movel25,318,372);
        ParedeFantasma movel26 = new ParedeFantasma();
        addObject(movel26,269,115);
        ParedeFantasma movel27 = new ParedeFantasma();
        addObject(movel27,365,115);
        ParedeFantasma movel28 = new ParedeFantasma();
        addObject(movel28,269,66);
        ParedeFantasma movel29 = new ParedeFantasma();
        addObject(movel29,365,66);
    }
    
    public void musica(boolean op){
        if(op==true){
            start.setVolume(40);
            start.playLoop();
            op=false;
        }
    }
}
