import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Itens.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
abstract class Itens extends Actor
{
    public void act() 
    {
         checkParede();
         checkPersonagem();
    }
    
    protected void checkParede(){
        Actor Parede;
        Parede = getOneIntersectingObject(Parede_Borda.class);
        
        if (Parede !=null){
            setLocation(Greenfoot.getRandomNumber(getWorld().getWidth()-1),Greenfoot.getRandomNumber(getWorld().getHeight()-1));
        }
        
        checkPet();
    }
    
    private void checkPet(){
        Actor P;
        P = getOneIntersectingObject(Pet.class);
        
        if (P !=null){
            if(Pet.meow.millisElapsed()>1000){
                int m = Greenfoot.getRandomNumber(4);
            
                switch (m){
                    case 0: Greenfoot.playSound("meow1.wav");
                    break;
                    case 1: Greenfoot.playSound("meow2.wav");
                    break;
                    case 2: Greenfoot.playSound("meow3.wav");
                    break;
                    case 3: Greenfoot.playSound("meow4.wav");
                    break;
                }
                Pet.meow.mark();
            }
            setLocation(Greenfoot.getRandomNumber(getWorld().getWidth()-1),Greenfoot.getRandomNumber(getWorld().getHeight()-1));
        }
    }
    
    abstract void checkPersonagem();
}
