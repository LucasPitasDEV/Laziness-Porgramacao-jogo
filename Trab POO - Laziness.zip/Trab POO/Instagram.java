import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Instagram.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Instagram extends Fantasma
{
    public static SimpleTimer insta = new SimpleTimer();
    
    public void act() 
    {
        super.act();
        
        if((getRotation()<=45)||(getRotation()>315)){
            setImage("InstaRight.png");
            
        }
        
        if((getRotation()>45)&&(getRotation()<=135)){
            setImage("InstaFront.png");
            
        }
        
        if((getRotation()>135)&&(getRotation()<=225)){
            setImage("InstaLeft.png");
            
        }
        
        if((getRotation()>225)&&(getRotation()<=315)){
            setImage("InstaBack.png");
            
        }
    }
}
