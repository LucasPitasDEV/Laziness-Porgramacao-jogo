import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Esc.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Esc extends Textos
{
    public void act() 
    {

    }    
}
