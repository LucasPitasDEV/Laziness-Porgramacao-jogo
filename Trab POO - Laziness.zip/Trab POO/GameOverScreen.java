import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe GameOverScreen.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class GameOverScreen extends World
{
    private SimpleTimer timerGameOver = new SimpleTimer();
    
    private F f = new F();
    
    private static int pontuacao=0;
    
    /**
     * Construtor para objetos da classe GameOverScreen.
     * 
     */
    public GameOverScreen()
    {    
        super(600, 400, 1);
        
        removeObjects(getObjects(Itens.class));
        removeObjects(getObjects(Fantasma.class));
        removeObjects(getObjects(Parede.class));
        
        GameOver gameOverImg = new GameOver();
        addObject(gameOverImg,300,000);
        
        pontuacao = Fase1.pontuacao.getValue();       
        
        StartScreen.startMusic=true;
        
        timerGameOver.mark();
        
        act();
    }
    
    public void act(){
        if(timerGameOver.millisElapsed()>2000){
            showText("Sua pontuacao foi: "+ pontuacao,300,250);
        }
        
        if(timerGameOver.millisElapsed()>3000){
            addObject(f, 302, 350);
        }
        
        if(Greenfoot.isKeyDown("f")){
            Greenfoot.playSound("BotoesMenu.wav");
            Greenfoot.setWorld(new ScoreScreen());
        }
    }
}
