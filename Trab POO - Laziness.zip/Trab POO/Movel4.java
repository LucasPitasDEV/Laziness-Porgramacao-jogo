import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Movel4.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Movel4 extends Parede_Borda
{
    public void act() 
    {

    }    
}
