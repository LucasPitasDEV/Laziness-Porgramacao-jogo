import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Personagem.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Personagem extends Actor
{ 
    private GreenfootImage f1 = new GreenfootImage("ChFront1.png");
    private GreenfootImage f2 = new GreenfootImage("ChFront2.png");
    private GreenfootImage f3 = new GreenfootImage("ChFront3.png");
    
    private GreenfootImage b1 = new GreenfootImage("ChBack1.png");
    private GreenfootImage b2 = new GreenfootImage("ChBack2.png");
    private GreenfootImage b3 = new GreenfootImage("ChBack3.png");
    
    private GreenfootImage r1 = new GreenfootImage("ChRight1.png");
    private GreenfootImage r2 = new GreenfootImage("ChRight2.png");
    private GreenfootImage r3 = new GreenfootImage("ChRight3.png");
    
    private GreenfootImage l1 = new GreenfootImage("ChLeft1.png");
    private GreenfootImage l2 = new GreenfootImage("ChLeft2.png");
    private GreenfootImage l3 = new GreenfootImage("ChLeft3.png");
    
    static int speed=3;
    static boolean escudo=false;
    private int frame=1;
    private int contAnimacao=0;
    
    public void act(){            
        movimentoCima();
        movimentoBaixo();
        movimentoEsquerda();
        movimentoDireita();
        
        contAnimacao++;
    }  
    
    private void movimentoCima(){
        if(Greenfoot.isKeyDown("w")){
            if(contAnimacao % 8== 0){
                animacaoCima();
            }
            
            setRotation(270);
            
            if((getOneObjectinFront(Parede.class)==null)&&(isTouching(Pet.class)==false))
                move(speed);           
        }          
    }
    
    private void animacaoCima(){
        if(frame==1){
            somAndar();
            setImage(b1);
        }
        else if(frame==2){
            somAndar();
            setImage(b2);
        }
        else{
            somAndar();
            setImage(b3);
            frame=1;
            return;
        }
        frame++;
    } 
    
    private void movimentoEsquerda(){
        if(Greenfoot.isKeyDown("a")){
            if(contAnimacao % 8== 0){
                animacaoEsquerda();
            }
            
            setRotation(180);
            
            if((getOneObjectinFront(Parede.class)==null)&&(isTouching(Pet.class)==false))
                move(speed);
            }
        }
    
    private void animacaoEsquerda(){
        if(frame==1){
            somAndar();
            setImage(l1);
        }
        else if(frame==2){
            somAndar();
            setImage(l2);
        }
        else{
            somAndar();
            setImage(l3);
            frame=1;
            return;
        }
        frame++;
    }    
        
    private void movimentoBaixo(){    
        if(Greenfoot.isKeyDown("s")){
            if(contAnimacao % 8== 0){
                animacaoBaixo();
            }
            
            setRotation(90);
            
            if((getOneObjectinFront(Parede.class)==null)&&(isTouching(Pet.class)==false))
                move(speed);
        }
    }
    
    private void animacaoBaixo(){
        if(frame==1){
            somAndar();
            setImage(f1);
        }
        else if(frame==2){
            somAndar();
            setImage(f2);
        }
        else{
            somAndar();
            setImage(f3);
            frame=1;
            return;
        }
        frame++;
    }
    
    private void movimentoDireita(){
        if(Greenfoot.isKeyDown("d")){
            if(contAnimacao % 8== 0){
                animacaoDireita();
            }
            
            setRotation(0);
            
            if((getOneObjectinFront(Parede.class)==null)&&(isTouching(Pet.class)==false))
                move(speed);
        } 
    }
    
    private void animacaoDireita(){
        if(frame==1){
            somAndar();
            setImage(r1);
        }
        else if(frame==2){
            somAndar();
            setImage(r2);
        }
        else{
            somAndar();
            setImage(r3);
            frame=1;
            return;
        }
        frame++;
    }
    
    private Actor getOneObjectinFront(Class c){
        GreenfootImage myImage = getImage();
        int distanceToFront = myImage.getWidth();
        int xOffset = (int) Math.ceil(distanceToFront*Math.cos(Math.toRadians(getRotation())))/2;
        int yOffset = (int) Math.ceil(distanceToFront*Math.sin(Math.toRadians(getRotation())))/2;

        return (getOneObjectAtOffset(xOffset, yOffset, c));
    }
    
    private void somAndar(){
        if(frame==1){
            Greenfoot.playSound("step1_1.wav");
        }
        else if(frame==2){
            Greenfoot.playSound("step2_1.wav");
        }
        else{
            Greenfoot.playSound("step3_1.wav");
            return;
        }
    }
}