import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe EndGameTexto.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class EndGameTexto extends Textos
{
    public void act() 
    {
        if(getY()<190)
            setLocation(getX(), getY()+2);
    }    
}
