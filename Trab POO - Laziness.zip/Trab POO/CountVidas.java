import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe CountVidas.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class CountVidas extends Counter
{
    private SimpleTimer tempoVida = new SimpleTimer();
    
    public void act() 
    { 
        imagem(Fase1.vidas.getValue());
        
        if(tempoVida.millisElapsed()>8000){
            if((Fase1.vidas.getValue()<3)&&(Fase1.vidas.getValue()!=0)&&(Greenfoot.getRandomNumber(1000)==1)){
                addVida();
            }
        }
    }    
    
    public void addVida(){
        int getX = Greenfoot.getRandomNumber(getWorld().getWidth()-1);
        int getY = Greenfoot.getRandomNumber(getWorld().getHeight()-1);
        
        getWorld().addObject(Fase1.vida, getX, getY);
        tempoVida.mark();
    }
    
    public void imagem(int vidas){
        if(vidas==3){
            setImage("Vida3.png");
        }
        
        else if (vidas==2){
            setImage("Vida2.png");
        }
        
        else if(vidas==1){
            setImage("Vida1.png");
        }
        
        else{
            setImage("Vida0.png");
        }
    }
}
