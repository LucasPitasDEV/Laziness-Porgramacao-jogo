import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Pet.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Pet extends Parede
{
    public static SimpleTimer meow = new SimpleTimer();
    
    private GreenfootImage f1 = new GreenfootImage("PetFront1.png");
    private GreenfootImage f2 = new GreenfootImage("PetFront2.png");
    
    private GreenfootImage b1 = new GreenfootImage("PetBack1.png");
    private GreenfootImage b2 = new GreenfootImage("PetBack2.png");
    
    private GreenfootImage r1 = new GreenfootImage("PetRight1.png");
    private GreenfootImage r2 = new GreenfootImage("PetRight2.png");
    
    private GreenfootImage l1 = new GreenfootImage("PetLeft1.png");
    private GreenfootImage l2 = new GreenfootImage("PetLeft2.png");
    
    private int frame=1;
    private int contAnimacao=0;
    
    public void act() 
    {     
        move(2);
        
        if(Greenfoot.getRandomNumber(100)<5)
            turn(Greenfoot.getRandomNumber(90)-45);
        
        if(contAnimacao % 8== 0){
                animacao();
        }    
            
        if(getOneObjectinFront(Parede.class)!=null)
            turn(180);  
            
        contAnimacao++;
    }
    
    private Actor getOneObjectinFront(Class c){
        GreenfootImage myImage = getImage();
        int distanceToFront = myImage.getWidth();
        int xOffset = (int) Math.ceil(distanceToFront*Math.cos(Math.toRadians(getRotation())))/2;
        int yOffset = (int) Math.ceil(distanceToFront*Math.sin(Math.toRadians(getRotation())))/2;

        return (getOneObjectAtOffset(xOffset, yOffset, c));
    }
    
    public void animacao(){
        if((getRotation()<=45)||(getRotation()>315)){
            if(frame==1){
                setImage(r1);
            }
            else{
                setImage(r2);
                frame=1;
                return;
            }

            frame++;            
        }
        
        if((getRotation()>45)&&(getRotation()<=135)){
            if(frame==1){
                setImage(f1);
            }
            else{
                setImage(f2);
                frame=1;
                return;
            }

            frame++; 
        }
        
        if((getRotation()>135)&&(getRotation()<=225)){
            if(frame==1){
                setImage(l1);
            }
            else{
                setImage(l2);
                frame=1;
                return;
            }

            frame++; 
        }
        
        if((getRotation()>225)&&(getRotation()<=315)){
            if(frame==1){
                setImage(b1);
            }
            else{
                setImage(b2);
                frame=1;
                return;
            }

            frame++; 
        }
    }
}
