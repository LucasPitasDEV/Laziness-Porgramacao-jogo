import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe CreditoScreen.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class CreditosScreen extends World
{
    private Esc esc = new Esc();
    
    /**
     * Construtor para a classe CreditosScreen.
     * 
     */
    public CreditosScreen()
    {    
        super(600, 400, 1);
        addObject(esc, 300,390);
        act();
    }
    
    public void act(){
        if(Greenfoot.isKeyDown("escape")){
            Greenfoot.playSound("BotoesMenu.wav");
            Greenfoot.setWorld(new StartScreen());
        }
    }
}
