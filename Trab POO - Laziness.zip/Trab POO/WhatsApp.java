import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe WhatsApp.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class WhatsApp extends Fantasma
{
    public static SimpleTimer whats = new SimpleTimer();
    
    public void act() 
    {
        super.act();
        
        if((getRotation()<=45)||(getRotation()>315)){
            setImage("WhatsRight.png");
            
        }
        
        if((getRotation()>45)&&(getRotation()<=135)){
            setImage("WhatsFront.png");
            
        }
        
        if((getRotation()>135)&&(getRotation()<=225)){
            setImage("WhatsLeft.png");
            
        }
        
        if((getRotation()>225)&&(getRotation()<=315)){
            setImage("WhatsBack.png");
            
        }
    } 
}
