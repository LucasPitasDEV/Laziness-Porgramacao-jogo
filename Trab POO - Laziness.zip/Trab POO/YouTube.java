import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Youtube.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class YouTube extends Fantasma
{
    public static SimpleTimer yt = new SimpleTimer();
    
    public void act() 
    {
        super.act();
        
        if((getRotation()<=45)||(getRotation()>315)){
            setImage("YtRight.png");
            
        }
        
        if((getRotation()>45)&&(getRotation()<=135)){
            setImage("YtFront.png");
            
        }
        
        if((getRotation()>135)&&(getRotation()<=225)){
            setImage("YtLeft.png");
            
        }
        
        if((getRotation()>225)&&(getRotation()<=315)){
            setImage("YtBack.png");
            
        }
    }  
}
