import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Facebook.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Facebook extends Fantasma
{
    public static SimpleTimer face = new SimpleTimer();
    
    public void act() 
    {
        super.act();
        
        if((getRotation()<=45)||(getRotation()>315)){
            setImage("FaceRight.png");
            
        }
        
        if((getRotation()>45)&&(getRotation()<=135)){
            setImage("FaceFront.png");
            
        }
        
        if((getRotation()>135)&&(getRotation()<=225)){
            setImage("FaceLeft.png");
            
        }
        
        if((getRotation()>225)&&(getRotation()<=315)){
            setImage("FaceBack.png");
            
        }
    }
}
