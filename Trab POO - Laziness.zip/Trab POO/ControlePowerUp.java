import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe ControlePowerUp.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class ControlePowerUp extends Actor
{   
    private SimpleTimer tempoPowerUp = new SimpleTimer();
    
    public static SimpleTimer cafeEfeito = new SimpleTimer();
    public static SimpleTimer escudoEfeito = new SimpleTimer();
    
    public void act() 
    {
        if(tempoPowerUp.millisElapsed()>7000){
            addPowerUp();
        }
        
        imagemEscudoHB();
        fimEfeitoCafe();
        fimEfeitoEscudo();
    }
        
    public void addPowerUp(){
        int getX = Greenfoot.getRandomNumber(getWorld().getWidth()-1);
        int getY = Greenfoot.getRandomNumber(getWorld().getHeight()-1);
            
        if(Greenfoot.getRandomNumber(2)==1){
            getWorld().addObject(Fase1.cafe, getX, getY);
        }
            
        else{
            getWorld().addObject(Fase1.escudo, getX, getY);
        }
        tempoPowerUp.mark();
    }
    
    private void imagemEscudoHB(){
        if(Personagem.escudo==true){
            getImage().setTransparency(255);
        }
        else{
            getImage().setTransparency(0);
        } 
    }
    
    private void fimEfeitoCafe(){
        if (cafeEfeito.millisElapsed() > 5000){
            Personagem.speed=3;
            
        }
    }
    
    private void fimEfeitoEscudo(){
        if ((escudoEfeito.millisElapsed() > 5000)&&(Personagem.escudo==true)){
            Personagem.escudo=false;
            Greenfoot.playSound("Escudo_Desativado.wav");
            
        }
    }
}