import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Movel.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Movel extends Parede_Borda
{
    public void act() 
    {

    }    
}
