import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe ParedeH2.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class ParedeH2 extends Parede_Borda
{
    public void act() 
    {

    }    
}
