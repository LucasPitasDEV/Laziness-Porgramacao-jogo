import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Cafe.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Cafe extends Itens{
    public void act() 
    {
        super.act();
    }
    
    void checkPersonagem(){
        Actor P;
        P = getOneIntersectingObject(Personagem.class);
    
        if (P !=null){
            Greenfoot.playSound("Cafe.wav");
            Personagem.speed = 6;
            ControlePowerUp.cafeEfeito.mark();
            getWorld().removeObject(this);
        }
    }   
}
