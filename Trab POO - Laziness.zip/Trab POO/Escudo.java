import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Escudo.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Escudo extends Itens
{
    public void act() 
    {   
        super.act();      
    } 
    
    void checkPersonagem(){
        Actor Per;
        Per = getOneIntersectingObject(Personagem.class);
    
        if (Per !=null){
            ControlePowerUp.escudoEfeito.mark();
            Greenfoot.playSound("Escudo.wav");
            Personagem.escudo=true;
            getWorld().removeObject(this);
        }
    }
}
