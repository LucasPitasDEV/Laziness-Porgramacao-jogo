import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe CountVidasBoss.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class CountVidasBoss extends Counter
{
    private SimpleTimer tempoTeams = new SimpleTimer();
    
    private Teams teams = new Teams(); 
    
    public static GreenfootSound win = new GreenfootSound("Win.wav");
    
    public static int teamsTela=0;
    private int som=0;
    
    public void act() 
    {
        if(tempoTeams.millisElapsed()>4000){
            if(teamsTela<3){
                addTeams();
                teamsTela++;
            }
        }
        
        checkVidas();
        barraVidas();
    }
    
    private void addTeams(){
        int getX = Greenfoot.getRandomNumber(getWorld().getWidth()-1);
        int getY = Greenfoot.getRandomNumber(getWorld().getHeight()-1);
        
        getWorld().addObject(teams, getX, getY);
        tempoTeams.mark();
    }
    
    private void checkVidas(){
        if(Fase1.bossVidas.getValue()==15){
            getWorld().removeObjects(getWorld().getObjects(WhatsApp.class));
            if(som==0){
                Greenfoot.playSound("FantasmaD.wav");
                som=1;
            }
        }
        
        if(Fase1.bossVidas.getValue()==10){
            getWorld().removeObjects(getWorld().getObjects(YouTube.class));
            if(som==1){
                Greenfoot.playSound("FantasmaD.wav");
                som=2;
            }
        }
        
        if(Fase1.bossVidas.getValue()==5){
            getWorld().removeObjects(getWorld().getObjects(Instagram.class));
            if(som==2){
                Greenfoot.playSound("FantasmaD.wav");
                som=3;
            }
        }
        
        if(Fase1.bossVidas.getValue()==0){
            getWorld().removeObjects(getWorld().getObjects(Facebook.class));
            if(som==3){
                Greenfoot.playSound("FantasmaD.wav");
                som=1;
            }
            Fase1.stage1.stop();
            Fase1.stage2.stop();
            Fase1.stage3.stop();
            Fase1.stage4.stop();
            Fase1.stage5.stop();
            win.playLoop();
            Fase1.pontuacao.add(100);
            Greenfoot.delay(165);
            Greenfoot.setWorld(new WinScreen());
        }
    }
    
    private void barraVidas(){
        
        GreenfootImage barraHp = new GreenfootImage(310,400);
        barraHp.setFont(new Font(true, false, 15));

        barraHp.setColor(Color.WHITE);
        barraHp.fillRect(9, 80, 44, 300);
        barraHp.setColor(Color.RED);
        if (Fase1.bossVidas.getValue()==20){
            barraHp.fillRect(14, 85, 35, 290);
        }
        if (Fase1.bossVidas.getValue()<20){
            int reducao = 15*(20-Fase1.bossVidas.getValue());
            int nvY = 85+reducao;
            int nvBase = 290-reducao;
            barraHp.fillRect(14, nvY, 35, nvBase);
        }
        
        setImage(barraHp);
        
    }
}
