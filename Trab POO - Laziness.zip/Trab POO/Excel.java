import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Excel.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Excel extends Itens
{
    private GreenfootSound excel = new GreenfootSound("Excel.wav");
    
    public void act() 
    { 
        super.act();
        checkFantasma();
    }
    
    void checkPersonagem(){
        Actor Personagem;
        Personagem = getOneIntersectingObject(Personagem.class);
        
        if (Personagem !=null){
            Fase1.pontuacao.add(5);
            excel.setVolume(90);
            excel.play();
            setLocation(Greenfoot.getRandomNumber(getWorld().getWidth()-1), Greenfoot.getRandomNumber(getWorld().getHeight()-1));
        }
    }
    
    private void checkFantasma(){
        Actor F1;
        F1 = getOneIntersectingObject(Facebook.class);
        
        Actor F2;
        F2 = getOneIntersectingObject(Instagram.class);
        
        Actor F3;
        F3 = getOneIntersectingObject(WhatsApp.class);
        
        Actor F4;
        F4 = getOneIntersectingObject(YouTube.class);
        
        if ((F1 !=null)||(F2 !=null)||(F3 !=null)||(F4 !=null)){
            Fase1.pontuacao.add(-3);
            if(Fase1.pontuacao.getValue()<0){
                Fase1.pontuacao.setValue(0);
            }
            
            if(F1 !=null){
               if(Facebook.face.millisElapsed()>1000){
                   Greenfoot.playSound("Facebook.wav");
                   Facebook.face.mark(); 
                }
            }
                
            if(F2 !=null){
               if(Instagram.insta.millisElapsed()>1000){
                   Greenfoot.playSound("Instagram.wav");
                   Instagram.insta.mark(); 
                }
            }
            
            if(F3 !=null){
               if(WhatsApp.whats.millisElapsed()>1000){
                   Greenfoot.playSound("Whatsapp.wav");
                   WhatsApp.whats.mark(); 
                }
            }
            
            if(F4 !=null){
               if(YouTube.yt.millisElapsed()>1000){
                   Greenfoot.playSound("Youtube.wav");
                   YouTube.yt.mark(); 
                }
            }
                
            setLocation(Greenfoot.getRandomNumber(getWorld().getWidth()-1), Greenfoot.getRandomNumber(getWorld().getHeight()-1));
        }
    }
}
