import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe ParedeV.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class ParedeV extends Parede_Borda
{
    public void act() 
    {

    }    
}
