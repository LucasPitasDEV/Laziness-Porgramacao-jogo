import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Parede_Borda.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Parede_Borda extends Parede
{
    public void act() 
    {

    }    
}
