import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Movel5.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Movel5 extends Parede_Borda
{
    public void act() 
    {

    }    
}
