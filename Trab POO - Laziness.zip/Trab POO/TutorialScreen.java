import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Class Tutorial.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class TutorialScreen extends World
{
    private SimpleTimer timer = new SimpleTimer();
    
    private Esc esc = new Esc();
    private P p = new P();
    private O o = new O();
    
    private int pagina =1;
    
    /**
     * Construtor para objetos da classe Tutorial.
     * 
     */
    public TutorialScreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1);
        act();
    }
    
    public void act(){
        if(Greenfoot.isKeyDown("escape")){
            Greenfoot.playSound("BotoesMenu.wav");
            StartScreen.startMusic=false;
            Greenfoot.setWorld(new StartScreen());
        }
        
        if((Greenfoot.isKeyDown("p"))&&(pagina<7)&&(timer.millisElapsed()>500)){
            Greenfoot.playSound("BotoesMenu.wav");
            timer.mark();
            pagina++;
        }
        
        if((Greenfoot.isKeyDown("o"))&&(pagina>1)&&(timer.millisElapsed()>500)){
            Greenfoot.playSound("BotoesMenu.wav");
            timer.mark();
            pagina--;
        }
        
        pagina(pagina);
    }
    
    private void pagina(int pag){
        if(pag==1){
            removeObjects(getObjects(Textos.class));
            setBackground("Tutorial1.jpg");
            addObject(esc, 150,370);
            addObject(p, 500,370);
        }
        
        else if(pag==2){
            removeObjects(getObjects(Textos.class));
            setBackground("Tutorial2.jpg");
            addObject(esc, 300,370);
            addObject(p, 500,370);
            addObject(o, 100,370);
        }
        
        else if(pag==3){
            removeObjects(getObjects(Textos.class));
            setBackground("Tutorial3.jpg");
            addObject(esc, 300,370);
            addObject(p, 500,370);
            addObject(o, 100,370);
        }
        
        else if(pag==4){
            removeObjects(getObjects(Textos.class));
            setBackground("Tutorial4.jpg");
            addObject(esc, 300,370);
            addObject(p, 500,370);
            addObject(o, 100,370);
        }
        
        else if(pag==5){
            removeObjects(getObjects(Textos.class));
            setBackground("Tutorial5.jpg");
            addObject(esc, 300,370);
            addObject(p, 500,370);
            addObject(o, 100,370);
        }
        
        else if(pag==6){
            removeObjects(getObjects(Textos.class));
            setBackground("Tutorial6.jpg");
            addObject(esc, 300,370);
            addObject(p, 500,370);
            addObject(o, 100,370);
        }
        
        else{
            removeObjects(getObjects(Textos.class));
            setBackground("Tutorial7.jpg");
            addObject(esc, 300,370);
            addObject(o, 100,370);
        }
    }
}
