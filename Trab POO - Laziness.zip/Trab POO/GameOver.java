import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe GameOver.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class GameOver extends EndGameTexto
{
    public void act() 
    {
        super.act();
    }    
}
