import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Texto.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Textos extends Actor
{
    public void act() 
    {

    }    
}
