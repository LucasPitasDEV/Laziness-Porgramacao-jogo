import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Teams.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Teams extends Itens
{    
    public void act(){
        super.act();
    } 
    
    void checkPersonagem(){
        Actor Personagem;
        Personagem = getOneIntersectingObject(Personagem.class);
        
        if (Personagem !=null){
            Fase1.bossVidas.add(-1);
            Greenfoot.playSound("Teams.wav");
            
            int hit = Greenfoot.getRandomNumber(4);
            
            switch (hit){
                case 0: Greenfoot.playSound("hit1.wav");
                break;
                case 1: Greenfoot.playSound("hit2.wav");
                break;
                case 2: Greenfoot.playSound("hit3.wav");
                break;
                case 3: Greenfoot.playSound("hit4.wav");
                break;
            }
            
            CountVidasBoss.teamsTela--;
            getWorld().removeObject(this);
        }
    }
}
