import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe ScoreScreen.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class ScoreScreen extends World
{   
    private Esc esc = new Esc();
    
    /**
     * Construtor para objetos da classe ScoreScreen.
     * 
     */
    public ScoreScreen()
    {    
        super(600, 400, 1);
        addObject(new ScoreBoard(500, 400), getWidth() / 2, getHeight() / 2);
        addObject(esc, 300,390);
        act();
    }
    
    public void act(){
        if(Greenfoot.isKeyDown("escape")){
            CountVidasBoss.win.stop();
            Fantasma.lose.stop();
            Greenfoot.playSound("BotoesMenu.wav");
            Greenfoot.setWorld(new StartScreen());
        }
    }
}
