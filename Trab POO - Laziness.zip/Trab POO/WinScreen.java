import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Class WinScreen.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class WinScreen extends World
{
    private SimpleTimer timerWin = new SimpleTimer();
    
    private F f = new F();
    
    private static int pontuacao=0;
    
    /**
     * Construtor para objetos da classe WinScreen.
     * 
     */
    public WinScreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1);
        
        removeObjects(getObjects(Itens.class));
        removeObjects(getObjects(Fantasma.class));
        removeObjects(getObjects(Parede.class));
        
        YouWin youWinImg = new YouWin();
        addObject(youWinImg,300,000);
        
        pontuacao = Fase1.pontuacao.getValue();       
        
        StartScreen.startMusic=true;
        
        timerWin.mark();
        
        act();
    }
    
    public void act(){
        if(timerWin.millisElapsed()>2000){
            showText("Sua pontuacao foi: "+ pontuacao,300,250);
        }
        
        if(timerWin.millisElapsed()>3000){
            addObject(f, 302, 350);
        }
        
        if(Greenfoot.isKeyDown("f")){
            Greenfoot.playSound("BotoesMenu.wav");
            Greenfoot.setWorld(new ScoreScreen());
        }
    }
}
