import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Vida.
 * 
 * @author Guilherme Henrique Alves 
 * @version 1.0
 */
public class Vida extends Itens
{
    private GreenfootSound vida = new GreenfootSound("Vida.wav"); 
    
    public void act() 
    { 
        super.act();
    }
    
    void checkPersonagem(){
        Actor Personagem;
        Personagem = getOneIntersectingObject(Personagem.class);
        
        if (Personagem !=null){
            vida.setVolume(90);
            vida.play();
            Fase1.vidas.add(1);
            getWorld().removeObject(this);
        }
    }
}
